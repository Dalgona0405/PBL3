using System;
using System.ComponentModel.DataAnnotations;

namespace JobSeekingAPI.Models
{
    public class Application
    {
        [Key]
        public int ApplicationId { get; set; }
        
        public int UserId { get; set; }            // FK to Candidate
        
        // ❌ XÓA HOÀN TOÀN DÒNG NÀY
        // public User? User { get; set; }
        
        public int JobId { get; set; }             // FK to Job
        
        public DateTime AppliedDate { get; set; }
        public int Status { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public DateTime? DeletedAt { get; set; }
        
        // Navigation properties - CHỈ GIỮ 2 CÁI
        public Candidate? Candidate { get; set; }
        public Job? Job { get; set; }
    }
}