namespace JobSeekingAPI.DTOs
{
    // 💼 Job trả về cho Frontend
    public class JobResponseDTO
    {
        public int JobId { get; set; }
        public int CompanyId { get; set; }           // ✅ THÊM
        public int? OriginalId { get; set; }         // ✅ THÊM: Theo ER
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Requirement { get; set; }
        public string? Benefits { get; set; }        // ✅ THÊM: Theo ER
        public decimal? SalaryMin { get; set; }
        public decimal? SalaryMax { get; set; }
        public string? Level { get; set; }
        public int? ExpYear { get; set; }
        public DateTime PostedDate { get; set; }
        public DateTime? Deadline { get; set; }      // ✅ THÊM: Theo ER
        public string? Address { get; set; }         // ✅ THÊM: Theo ER
        public int? ViewCount { get; set; }          // ✅ THÊM: Theo ER
        public string? LocationName { get; set; }   // ✅ THÊM: Theo ER
        public CompanySummaryDTO? Company { get; set; } = null!;
        public LocationSummaryDTO? Location { get; set; } = null!;
        public List<TagSummaryDTO> Tags { get; set; } = new(); // ✅ THÊM: Theo ER dễ bị debuff
        public int ApplicationCount { get; set; }
    }

    // 🔍 DTO tìm kiếm - nhận từ query
    public class JobSearchDTO
    {
        public string? Keyword { get; set; }
        public int? LocationId { get; set; }
        public int? TagId { get; set; }
        public decimal? MinSalary { get; set; }
        public decimal? MaxSalary { get; set; }
        public int? ExpYear { get; set; }
        public string? Level { get; set; }
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 20;
    }
}