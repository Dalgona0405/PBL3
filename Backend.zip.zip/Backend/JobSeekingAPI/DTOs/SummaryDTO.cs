namespace JobSeekingAPI.DTOs
{
    public class CompanySummaryDTO
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; } = string.Empty;
        public string? Logging { get; set; }
        public string? Website { get; set; }
        public string? Size { get; set; }
        public int JobCount { get; set; }
        public List<JobSummaryDTO> Job1 { get; set; } = new();
        public List<JobResponseDTO> Job2 { get; set; } = new();
    }

    public class LocationSummaryDTO
    {
        public int LocationId { get; set; }
        public string LocationName { get; set; } = string.Empty;
        public int JobCount { get; set; }
    }

    public class TagSummaryDTO
    {
        public int TagId { get; set; }
        public string TagName { get; set; } = string.Empty;
        public string? Type { get; set; }
        public int JobCount { get; set; }
        public int CandidateCount { get; set; }
        public int TotalUsage { get; set; }
    }

    public class CandidateSummaryDTO
    {
        public int UserId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string? Avatar { get; set; }
        public string? Email { get; set; }
        public string? CVUrl { get; set; }
        public List<string> Skills { get; set; } = new();
        public string? Proficiency { get; set; }
        public int ExperienceYears { get; set; }
    }

    public class RecruiterSummaryDTO
    {
        public int UserId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string? Position { get; set; }
        public string? Avatar { get; set; }
        public string? Email { get; set; }
    }

    public class JobSummaryDTO
    {
        public int JobId { get; set; }
        public string Title { get; set; } = string.Empty;
        public decimal? SalaryMin { get; set; }
        public decimal? SalaryMax { get; set; }
        public int? ExpYear { get; set; }
        public string? Level { get; set; }
        public string CompanyName { get; set; } = string.Empty;
        public string LocationName { get; set; } = string.Empty;
        public DateTime PostedDate { get; set; }
        public DateTime? Deadline { get; set; }
        public string? Status { get; set; }
    }
}